package eone.fcs.view.dialogs;

import org.eclnt.dataapp.view.app.util.EditorBeanGridFrameListEditor;
import org.eclnt.editor.annotations.CCGenClass;

import eone.fcs.data.entities.*;
import eone.fcs.view.dialogs.generated.*;

@CCGenClass (expressionBase="#{d.FCSMSEGBeanGrid}")

public class FCSMSEGBeanGrid
    extends FCSMSEGBeanGrid_GENERATED 
{
}
